
AidData - AidData.org

Dataset: EM-DAT Phillipines 1980-2012, geocoded
Released: 2016-08-03

Overview:
* This geocoded dataset represents all natural disaster records in EM-DAT’s database for the Philippines between 1980 and 2012. The ‘disasters.csv’ file contains 421 records pertaining to individual disasters, and the ‘locations.csv’ file contains 1815 location records that relate (many to one) to corresponding records in the ‘disasters.csv’ file. These tables are combinable through the ‘disaster_id’ field.

* Please direct any questions to data@aiddata.org


Included Files:

* ’data_dictionary.csv’ - includes attribute definitions for each file
* ’disasters.csv’ - contains records pertaining to individual disaster events
* ’locations.csv’ - contains records pertaining to individual disaster event locations
* ’disasters_locations_merged.csv’ - a merged version of the ‘disasters.csv’ and ‘locations.csv’ files
* ’license.txt’ - license information for this dataset
* ’README.txt’ - documentation pertaining to this dataset


Caveats:

* The ‘disasters_locations_merged.csv’ file contains a ‘ready to be mapped’ table of records where both project and location information is present for each record. A new attribute field ‘even_split_dam_usd’ is added to this table to represent each disaster’s ‘total_dam_usd’ value, divided by the count of that disaster’s associated locations. Coordinates pertaining to projects with ‘precision_code’ values of 6 and 8 were also removed from this file, as these are not granular enough to be informative alongside subnational location records.

* The disaster record with a ’disaster_id’ of ‘2002-858’ had its ‘year’ attribute changed from 2002 to 2003 based on the start and end dates provided with the record. done to maintain consistency within dataset.

* 183 records had damage financial amounts of 0 and attributes of no_killed, no_injured, no_affected, no_homeless, and total_affected each had a variable number of records of 0. According to EM-DAT, “Empty fields in the EM-DAT database usually indicate missing values or non-reported information. A ‘0’ in EM-DAT does not represent a value, and can signal that no information is available.”


EM-DAT General Background:

For more information on EM-DAT and their data, see their FAQ, explanatory notes, and disaster classification pages:

* http://www.emdat.be/frequently-asked-questions

* http://www.emdat.be/explanatory-notes

* http://www.emdat.be/classification


License:

* See license.txt for license information