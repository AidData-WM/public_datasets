#################################################################
# 20.3.2015
# Replication files for 
# Gibson, Clark C., Barak D. Hoffman, and Ryan S. Jablonski. 
# "Did Aid Promote Democracy in Africa? The Role of Technical Assistance in Africa’s Transitions." 
# World Development 68 (2015): 323
# Estimated on R version 2.14.2 (2012-02-29)
#################################################################

rm(list = ls())
set.seed(123)
library(foreign)
library(ggplot2)

#Load dataset. All variables are demeaned by country (code) since we're estimating a fixed effects regression. 
aid<-read.dta("AidDemocracyReplicationDemeanedFigure3.dta")
aid$yvar<-aid$log_wages_gdp
aid$treat<-aid$log_tagrant_gdp 
aid<-subset(aid, !is.na(yvar) & !is.na(treat)  & !is.na(s3un4608) & !is.na(pts) & !is.na(log_urban) & !is.na(log_gdppop) & !is.na(log_oda_gdp) & !is.na(log_pop)  & !is.na(coldwar) & !is.na(gdp_growth) & !is.na(code) )

#Code to estimate linear predictions along with clustered standard errors
robust.se <- function(model, cluster){
	 require(sandwich)
	 require(lmtest)
	 M <- length(unique(cluster))
	 N <- length(cluster)
	 K <- model$rank
	 dfc <- (M/(M - 1)) * ((N - 1)/(N - K))
	 uj <- apply(estfun(model), 2, function(x) tapply(x, cluster, sum));
	 rcse.cov <- dfc * sandwich(model, meat = crossprod(uj)/N)
	 rcse.se <- coeftest(model, rcse.cov)
	 #return(list(rcse.cov, rcse.se))
	return( rcse.cov )
}

predict.robust <- function(x,clcov,newdata){
	if(missing(newdata)){ newdata <- x$model }
	tt <- terms(x)
	Terms <- delete.response(tt)
	m.mat <- model.matrix(Terms,data=newdata)
	m.coef <- x$coef
	fit <- as.vector(m.mat %*% x$coef)
	se.fit <- sqrt(diag(m.mat%*%clcov%*%t(m.mat)))
	return(list(fit=fit,se.fit=se.fit))
}



lm.out <- lm(yvar ~ treat  + s3un4608 +  pts + log_urban + log_gdppop + log_oda_gdp + log_pop + coldwar + gdp_growth,  data=aid)
summary(lm.out)
se=robust.se(lm.out, aid$code)
se

new.data = with(aid, expand.grid(treat= seq(min(treat), max(treat), by=.001),
	s3un4608=mean(s3un4608, na.rm=TRUE),
	pts=mean(pts, na.rm=TRUE),
	log_urban=mean(log_urban, na.rm=TRUE),
	log_gdppop=mean(log_gdppop, na.rm=TRUE),
	log_oda_gdp=mean(log_oda_gdp, na.rm=TRUE),
	log_pop=mean(log_pop, na.rm=TRUE),
	coldwar=mean(coldwar, na.rm=TRUE),
	gdp_growth=mean(gdp_growth, na.rm=TRUE)
	))
	
new.data$yhat <- predict.robust(lm.out, se, newdata = new.data)$fit
new.data$yhat_se <- predict.robust(lm.out, se, newdata = new.data)$se.fit

predictplot = ggplot(new.data, aes(x=treat, y=(exp(yhat)-1))) + 
geom_linerange(aes(x=treat, ymax=(exp(yhat+(1.96*yhat_se))-1), ymin=(exp(yhat-(1.96*yhat_se)))-1), colour="gray")+
scale_x_continuous(expand = c(0.01, 0), breaks=c(-0.01, .1), labels=c("MIN\n0", "MAX\n0.21")) +
scale_y_continuous(breaks=c(seq(0, 10, by=2)), labels=seq(0, .10, by=.02))+
geom_line(colour="black", width=1, size=1) + 
theme_bw(base_family="serif", base_size=21) +
ylab("Public Wages/GDP") +
xlab("Technical Assistance/GDP") +
theme(
	panel.grid.major=element_blank(),
	panel.grid.minor=element_blank(), 
	panel.border = element_blank(), 
	panel.background = element_blank(),
	axis.line = element_line(colour = "black", size=1),
	plot.margin =  unit(c(1,1,1,1), "cm"),
	axis.title.x = element_text(vjust = 0),
	axis.title.y = element_text(vjust = -.01),
	axis.text.x = element_text(size=20),
	axis.ticks.x = element_line(colour = "black", size=1)
	) 
predictplot

ggsave("Figure3.tiff", plot = predictplot, width = 7, height = 7, dpi=500)


