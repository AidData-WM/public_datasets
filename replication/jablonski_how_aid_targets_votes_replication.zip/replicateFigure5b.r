#######################################################################
#This file replicates Figure 5b in
#Jablonski, Ryan. "How Aid Targets Votes: 
#The Impact of Electoral Incentives on Foreign Aid Distribution" World Politics
#Version: 4/26/2013
#######################################################################

rm(list = ls())

mean <- c(2.170447,1.30061)
upper <- c(2.516133,1.375238)
lower <- c(1.865969,1.22536)

tiff("Figure5b.tif",width=1500,height=1800)

ylimits=c(1.0,2.50)
maintitle=NA
    
x.axis <- c(1,.5)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis
font.type=5
font.size=8

par(
	mar=c(25, 26, 23, 23),
	font.main=font.type,
	font.axis=font.type,
	font.lab=font.type,
	font.sum=font.type)

#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot( x.axis, mean, 
	axes = F, 
	type = "p", 
	ylab="", 
	xlab = "",
	pch = 19, 
	cex = font.size, 
	cex.lab=1.5,
	xlim = c(.25,1.25), 
	ylim=ylimits,xaxs = "r") 



title(xlab="", main = maintitle, cex.lab=font.size, cex.main=font.size)

mtext(text="Aid per Capita (USD)", side = 2, line = 18, cex=font.size*1.15, font=font.type)
mtext(text="Coethnic Constituency", side = 1, line = 15, cex=font.size*1.15, font=font.type)


segments(x.axis, lower, x.axis, upper, lwd =  35, col="gray48")
points(x.axis, mean, type = "p", pch = 19, cex = 15	)



axis(1,
	at=x.axis,
	labels= c(1,0),
	tick=TRUE,
	lwd=12,
	padj=1.3,
	cex.axis=font.size,
	tck=-.02
)

axis(1,
	at=c(2,0),
	labels= c(1,0),
	tick=TRUE,
	lwd=12,
	padj=1.3,
	cex.axis=font.size,
	tck=-.02
)

axis(1,
	at=c(0,.5),
	labels= NA,
	tick=FALSE,
	lwd=12,
	padj=1.5,
	cex.axis=font.size,
)


axis(2,
at=c(1.0, 1.5, 2.0, 2.5),
lwd=12,
padj=-1,
cex.axis=font.size,
tck=-.02
)



dev.off()

    
