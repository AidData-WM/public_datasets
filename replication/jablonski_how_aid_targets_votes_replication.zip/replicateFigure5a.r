#######################################################################
#This file replicates Figure 5a in
#Jablonski, Ryan. "How Aid Targets Votes: 
#The Impact of Electoral Incentives on Foreign Aid Distribution" World Politics
#Version: 4/26/2013
#######################################################################

rm(list = ls())
set.seed(123)
library(foreign)
library(Zelig)
projects<-read.dta("replicationdata_demeaned_figure5.dta")

projects<-subset(projects, !is.na(projects$victory_margin))
projects<-subset(projects, !is.na(projects$log_constituency_aid_cap))

projects$victory_margin=projects$victory_margin*100
treat.min=min(projects$victory_margin)
treat.max=max(projects$victory_margin)
treat.range = (treat.min):treat.max

log_constituency_aid_cap.min = min(projects$log_constituency_aid_cap) 
log_constituency_aid_cap.max = max(projects$log_constituency_aid_cap) 

z.out <- zelig(log_constituency_aid_cap ~ victory_margin + perc_poverty  + log_taxrevenue  + log_gdp + trend + log_population + rrregimes_1 + rrregimes_2 + rrregimes_3, model="ls", data=projects, robust=TRUE)
summary(z.out)

x.out.range <- setx(z.out, victory_margin=treat.range, data=projects)
s.out.range <- sim(z.out, x=x.out.range)
summary(s.out.range)

xcount = length(s.out.range$qi$ev[1,])

fout.upper=function(x,obj=s.out.range)
{
	exp(quantile(obj$qi$ev[,x],probs=c(.95)))-1
}
fout.lower=function(x,obj=s.out.range)
{
	exp(quantile(obj$qi$ev[,x],probs=c(.05)))-1
}
fout.mean=function(x,obj=s.out.range)
{
	exp(mean(obj$qi$ev[,x]))-1
}
y.min=min(exp(s.out.range$qi$ev)-1)
y.max=max(exp(s.out.range$qi$ev)-1)


s.out.range.upper=lapply(x<-1:xcount, fout.upper, obj=s.out.range)
s.out.range.lower=lapply(x<-1:xcount, fout.lower, obj=s.out.range)
s.out.range.mean=lapply(x<-1:xcount, fout.mean, obj=s.out.range)

xaxis<- treat.min:treat.max

tiff("Figure5a.tif",width=1700,height=2000)

font.size=8
font.type=5
par(
	mar=c(40.1,35.1,20.1,15.1),
	font.main=font.type,
	font.axis=font.type,
	font.lab=font.type,
	font.sum=font.type
	)

plot(xaxis,s.out.range.mean, 
	cex=1,
	xlim=c(treat.min,treat.max),
	ylim=c(0,3),
	pch=".",
	axes=FALSE,
	main="",
	ylab="", 
	xlab="",
	cex.lab=font.size,
	cex.main=font.size
	)

mtext(text="Aid per Capita (USD)", side = 2, line = 20, cex=font.size*1.15, font=font.type)
mtext(text="Victory Margin", side = 1, line = 15, cex=font.size*1.15, font=font.type)


for (i in 1:length(xaxis)){
	y1=c(s.out.range.upper[i],s.out.range.lower[i])
	y2=c(s.out.range.upper[i],s.out.range.lower[i])
	x = i-abs(min(xaxis))
	x1=c(x,x)
	lines(x1, y1, lwd=10,lty=1, col="gray48")
	lines(x1, y2, lwd=10,lty=1, col="gray48")
}

points(
x<-xaxis,s.out.range.mean, 
	col = c("black"),
	bg = c("black"),
	cex=30,
	pch="."
)

lines(
x<-xaxis,s.out.range.mean, 
	col = c("black"),
	lwd=12
)


axis(1,
	at=c(treat.min,treat.max-1),
	labels= c("MIN\n(-100)", "MAX\n(100)"),
	tick=TRUE,
	lwd=12,
	padj=1.5,
	cex.axis=font.size,
	tck=-.02
)

axis(2,
at=c(0,1,2,3),
labels=c(0,1, 2,3),
lwd=12,
padj=-1,
cex.axis=font.size,
tck=-.02
)


dev.off()
