#######################################################################
#This file replicates Figure 6 and 7 in
#Jablonski, Ryan. "How Aid Targets Votes: 
#The Impact of Electoral Incentives on Foreign Aid Distribution" World Politics
#Version: 4/26/2013
#######################################################################

rm(list = ls())

#Remove the appropriate comments to create the associated panel

####MOI####
#maintitle="Moi Regime\n1992-2002"
#Victory Margin
#var.names <- c("RegimeVictoryMargin*Regime  ", "RegimeVictoryMargin  ")
#coef.vec <- c( .1461827, -.0938826)
#se.vec <- c(.0669436 ,  .0734996 )
#Coethnicity
#var.names <- c("RegimeEthnic*Regime  ", "RegimeEthnic  ")
#coef.vec <- c( .3594393, -.2920357)
#se.vec <- c(.1191433  ,  .1005159  )

#####KIBAKI####
#maintitle="Kibaki Regime\n2003-2007"
#Victory Margin
#var.names <- c("RegimeVictoryMargin*Regime  ", "RegimeVictoryMargin  ")
#coef.vec <- c(.4701621, -.2006833 )
#se.vec <- c(.1017304 , .0592957)
#Coethnicity
#var.names <- c("RegimeEthnic*Regime  ", "RegimeEthnic  ")
#coef.vec <- c(.3786794 , -.0823257)
#se.vec <- c( .0938513 , .0716712)

####PNU KIBAKI####
#maintitle="Kibaki/PNU"
#Victory Percent
#var.names <- c("PNU Percent*Regime  ", "PNU Percent  ")
#coef.vec <- c(-.2283838, .0233359 )
#se.vec <- c(.1993205, .1143097)
#Coethnicity
#var.names <- c("Kikuyu Ethnic*Regime  ", "Kikuyu Ethnic  ")
#coef.vec <- c(-.4538441, .0927562)
#se.vec <- c(.1019776 ,  .0720012)

####ODM ODINGA####
#maintitle="Odinga/ODM"
#Victory Percent
#var.names <- c("ODM Percent*Regime  ", "ODM Percent  ")
#coef.vec <- c(.4526096  , -.2005743 )
#se.vec <- c(.1451092 , .105989 )
#Coethnicity
#var.names <- c("Luo Ethnic*Regime  ", "Luo Ethnic  ")
#coef.vec <- c(.309078, -.1580938)
#se.vec <- c(.124114 , .076186 )

tiff("Figure6a.tif",width=1700,height=2000)

ylimits=c(.25,2.75)

    
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis

font.type=5
font.size=8

par(
	mar=c(25, 60, 80, 2),
	font.main=font.type,
	font.axis=font.type,
	font.lab=font.type,
	font.sum=font.type)

plot(coef.vec, y.axis, axes = F, type = "p", ylab = "", xlab = "",pch = 19, cex = font.size, 
	cex.lab=10.5, cex.axis=10, xlim = c(-0.7,0.7), ylim=ylimits,xaxs = "r") 

mtext(text="b", side = 1, line = 13, cex=7, font=6)
mtext(text=maintitle, side = 3, line =2, cex=6, font=font.type)

segments(coef.vec-qnorm(.975)*se.vec, y.axis, coef.vec+qnorm(.975)*se.vec, y.axis, lwd =  15, col="black")
points(coef.vec, y.axis, type = "p", pch = 19, cex = 6	)


axis(1, at = seq(-1,1,by=.5), labels = NA, tick = T,
    cex.axis = 1.2, mgp = c(2,.6,0), lwd=3)

axis(1, at = seq(-1,1,by=.5), labels =  c(-1, -.5, 0, .5, 1), tick = T,#draw x-axis and labels with tick marks
    cex.axis = 6, mgp = c(2,5,0), lwd=3, tck=-.04)#reduce label size, moves labels closer to tick marks    


axis(2, at = y.axis, label = var.names, las = 1, tick = T, ,mgp = c(2,.6,0),
    cex.axis = 5, lwd=3, tck=-.03) #draw y-axis with tick marks, make labels perpendicular to axis and closer to axis
segments(0,0,0,17,lty=2, lwd=5) # draw dotted line through 0
box(bty = "l", lwd=3) #place box around plot

dev.off()

    
